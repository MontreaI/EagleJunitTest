package EaglePackage;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Base64;
import java.io.*;

public class DeviceList {
	 public int DeviceInfoList() throws IOException {
		 URL url = new URL("http://192.168.0.20/cgi-bin/post_manager");
		  HttpURLConnection httpCon = (HttpURLConnection) url.openConnection();
		  httpCon.setConnectTimeout(30000);
		  String user_pass = "002da9:4587b7a7b36e4174";
		String encoded = Base64.getEncoder().encodeToString(user_pass.getBytes());
		httpCon.setRequestProperty("Authorization", "Basic " + encoded);
		  httpCon.setDoOutput(true);
		  httpCon.setDoInput(true);
		  
		      httpCon.setRequestProperty ( "Content-Type", "text/xml" );

		    OutputStreamWriter writer = new OutputStreamWriter( httpCon.getOutputStream() );

		    writer.write( "<Command><Name>device_list</Name></Command>" );

		    writer.flush();

		    writer.close();
		    
		        // reading the response

		    InputStreamReader reader = new InputStreamReader( httpCon.getInputStream() );
		    StringBuilder buf = new StringBuilder();
		    char[] cbuf = new char[ 2048 ];
		    int num;
		    while ( -1 != (num=reader.read( cbuf )))
		    {
		        buf.append( cbuf, 0, num );
		    }
		    String result = buf.toString();
		    System.err.println( "\n" + result ); 
			String EMPTY = "<DeviceList>\n</DeviceList>";
			if(result.equals(EMPTY)){
				return 1;
			}else{
				return 0;
			}
	 }
}