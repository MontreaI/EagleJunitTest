package EaglePackage;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

public class connectionTest {

	@Test
	public void ConnectionTest() throws IOException {
		EagleCommand junit = new EagleCommand();
		int result = junit.checkConnection();
		assertEquals(200, result);
	}

}
