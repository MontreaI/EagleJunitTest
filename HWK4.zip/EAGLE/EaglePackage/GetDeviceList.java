package EaglePackage;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

public class GetDeviceList {

	@Test
	public void GetDevices() throws IOException {
		DeviceList junit = new DeviceList();
		int result = junit.DeviceInfoList();
		assertEquals(0, result);
	}

}
