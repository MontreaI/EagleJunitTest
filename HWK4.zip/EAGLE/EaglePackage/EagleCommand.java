package EaglePackage;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Base64;
import java.io.*;

public class EagleCommand {
	 public int checkConnection() throws IOException {
		  URL url = new URL("http://192.168.0.20/cgi-bin/post_manager");
		  HttpURLConnection httpCon = (HttpURLConnection) url.openConnection();
		  String user_pass = "002da9:4587b7a7b36e4174";
		String encoded = Base64.getEncoder().encodeToString(user_pass.getBytes());
		httpCon.setRequestProperty("Authorization", "Basic " + encoded);
		  httpCon.setDoOutput(true);
		  httpCon.setDoInput(true);
		  httpCon.setRequestMethod("POST");
		  OutputStreamWriter out = new OutputStreamWriter(
		  httpCon.getOutputStream());
		  System.out.println(httpCon.getResponseCode());
		  int response = httpCon.getResponseCode();
		  System.out.println(httpCon.getResponseMessage());
		  out.close();
		  return response;
		 }
}
